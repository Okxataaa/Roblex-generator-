
function generate() {
  const username = document.getElementById("username").value;
  const loading = document.getElementById("loading");
  const result = document.getElementById("result");
  const userOutput = document.getElementById("userOutput");
  const robuxOutput = document.getElementById("robuxOutput");
  const verifyLink = document.getElementById("verifyLink");

  if (username.trim() === "") {
    alert("Please enter your Roblox username.");
    return;
  }

  loading.style.display = "block";
  result.style.display = "none";

  setTimeout(() => {
    loading.style.display = "none";
    result.style.display = "block";
    userOutput.textContent = username;
    robuxOutput.textContent = Math.floor(Math.random() * 10000) + 1000;
    verifyLink.href = "https://yourshortlink.com/abc123";
  }, 3000);
}
